import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

Vue.mixin({
  data(){
    return {
      hh: '嗨咯',
      did: '滴滴'
    }
  }
})

router.beforeEach((to, from, next) => {
  if (to.path === '/about' || to.path === '/haha') {
    if (localStorage.getItem('login') === 'success'){
      next()
    } else {
      next('/login')
    }
  } else {
    next()
  }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
