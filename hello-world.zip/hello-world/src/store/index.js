import Vue from 'vue'
import Vuex from 'vuex'
import axios from '../utils/axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    list: ['lucy', 'tom', 'jack'],
    age: 23,
    desc: '这是一只描述来自于vuex',
    arr: [],
    name: 'nina',
    rmb: 3000
  },
  mutations: {
    changeStateDesc(state, data){
      state.desc = data
    },
    changeStateAge(state, data){
      state.age = data
    },
    changeTheName(state, data){
      state.name = data
    },
    getDataActions(state, data){
      state.arr = data
    }
  },
  actions: {
    getStateData(store, data){
      axios({
        url: '/item/cateList.json',
        method: 'GET',
        params: {}
      }).then(res => {
        console.log(res)
        store.commit('getDataActions', res.data.categoryL1List)
      })
    },
    changeName(store, data){
      store.commit('changeTheName', data)
    }
  },
  getters: {
    rmb(state, getter){
      return state.rmb + '￥'
    }
  },
  modules: {
    hehe: {
      namespaced: true,
      state: {
        msg: 'hello',
        msg2: '这是msg2'
      },
      mutations: {
        changeHeheMsg(state, data){
          state.msg = data
        },
        changeHeheActions(state, data){
          state.msg2 = data
        }
      },
      actions: {
        changeHeheStateAction(store , data){
          store.commit('changeHeheActions', data)
        }
      },
      getters: {
        rmb2(){
          return 100 + '$'
        }
      },
      modules: {}
    }
  }
})
