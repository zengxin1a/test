<template>
  <div class="home">
    <div>这是home页面</div>
    <div>这里是辅助函数操作页</div>

    <hr>
    <div>外层的即不是子module里的数据可以直接在数组里面拿，子module的只能通过对象的写法</div>
    <div>{{list}}</div>
    <div>{{age}}</div>
    <hr>
    <div>这里开始是hehe子module的数据</div>
    <div>{{msg1}}</div>
    <hr>
    <div>这里开始getters</div>
    <div>{{rmb}}</div>
    <div>{{heheRmb2}}</div>
    <div @click="appl">点我</div>
  </div>
</template>

<script>
// @ is an alias to /src

// mapState跟mapGetters都要写在computed里面

import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
export default {
  name: 'Home',
  components: {
  },
  computed: {
    ...mapState(['list', 'age']),
      ...mapState({
        msg1: state => state.hehe.msg //子module的数据只能通过对象的形式 + 箭头函数返回，访问可以直接this.msg1访问，放HTML标签可以直接写，this都不要
      }),
        ...mapGetters(['rmb', 'hehe/rmb2']),
    ...mapGetters({
      heheRmb2: 'hehe/rmb2'
    })
  },
  methods:{
    appl(){
      console.log(this['hehe/rmb2'])
      // this.changeStateDesc('改变了')
      // this['hehe/changeHeheMsg'](88888)
      this.change1('改变了')
      this.change2(8888)
      this.changeName('小明')
      this.changeHehe('改变hehe里的msg2')
    },
    // ...mapMutations(['changeStateDesc', 'hehe/changeHeheMsg']),
    ...mapMutations({
      change1: 'changeStateDesc',
      change2: 'hehe/changeHeheMsg'
    }),
    ...mapActions(['changeName']),
    ...mapActions({
      changeHehe:  'hehe/changeHeheStateAction'
    })
  }
}
</script>
