<template>
  <div>
    这里是404
  </div>
</template>

<script>
export default {
  name: 'NotFound'
}
</script>

<style scoped lang="scss">

</style>
