<template>
  <div>
    <div @click="click3">{{msg}}</div>
  </div>
</template>

<script>
  export default {
    name: 'Haha',
    data(){
      return {
        msg: '哈哈组件'
      }
    },
    methods: {
      click3(){
        console.log(this.$route)
      }
    }
  }
</script>

<style scoped lang="scss">

</style>
