<template>
  <div @click="click4">
    动态路由
    <div>{{id}}</div>
  </div>
</template>

<script>
export default {
  name: 'active',
  methods: {
    click4(){
      // 动态路由传参，拿值的话 this.$route.id   id就是路由里面设置的路由后面的参数，设置的什么就用什么取值
      console.log(this.$route)
    }
  },
  props: ['id'],

}
</script>

<style scoped lang="scss">

</style>
