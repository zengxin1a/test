<template>
  <div>
    <div>登录页面</div>
    <input type="text">
    <button @click="log">登录</button>
  </div>
</template>

<script>
export default {
  name: 'Login',
  methods: {
    log(){
      localStorage.setItem('login', 'success')
    }
  }
}
</script>

<style scoped lang="scss">

</style>
