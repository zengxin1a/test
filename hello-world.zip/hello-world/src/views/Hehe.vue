<template>
  <div>
    <div @click="hclick">{{msg}}</div>
    <hr />
    <div>{{this.$store.state.desc}}</div>
    <div>年龄：{{this.$store.state.age}}</div>
    <div>{{this.$store.state.arr}}</div>
    <div>{{this.$store.state.name}}</div>
    <div>{{this.$store.getters.rmb}}</div>
    <div>{{this.$store.state.hehe.msg}}</div>
    <hr>
    <button @click="changDesc">点我改变desc</button>
    <button @click="changeStateAge">点我改变年龄</button>
    <button @click="getStateData">点我请求获取异步数据</button>
    <button @click="changeStateName">点我改变nina</button>
    <button @click="changeStateHehe">点我改变hehe的modules的state的数据</button>
  </div>
</template>

<script>
export default {
  name: 'Hehe',
  data(){
    return {
      msg: '呵呵组件'
    }
  },
  methods: {
    changDesc(){
      this.$store.commit('changeStateDesc', '这是已经改变的desc，发去vuex的')
    },
    changeStateAge(){
      this.$store.commit('changeStateAge', 18)
    },
    getStateData(){
      this.$store.dispatch('getStateData')
    },
    changeStateName(){
      this.$store.dispatch('changeName', 'tom')
    },
    changeStateHehe(){
      this.$store.commit('hehe/changeHeheMsg', '改成嗨咯')
      console.log(this.$store)
    },
    changeStateHeheActions(){
      this.$store.dispatch('changeHeheStateAction', '改变呵呵里面的')
    },
    hclick(){
      this.$router.push({
        // 传参分两组  name + params 和 path + query
        // 取值分别通过 this.$route.params 和 this.$route.query
        // name + params 相当于post 传的值在地址栏看不到 ， path + query相当于get会显示在地址栏
        // 动态路由也要通过params来取值 但是数据会显示在地址栏

        name: 'about',
        params: {
          username: 'lucy',
          age:23
        }
        // path: '/Haha',
        // query: {
        //   username: 'lili',
        //   age: 23
        // }
      })
    }
  }
}
</script>

<style scoped lang="scss">

</style>
