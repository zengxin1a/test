<template>
  <div>
    子路由
  </div>
</template>

<script>
export default {
name: 'Child',
  methods: {
  // console.log()
  }
}
</script>

<style scoped lang="scss">

</style>
