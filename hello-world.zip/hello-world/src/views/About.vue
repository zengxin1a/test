<template>
  <div class="about">
    <h1 @click="click2">This is an about page</h1>
    <router-link tag="div" to="/about/child">点我加载子路由</router-link>
    <router-view></router-view>
    <div @click="click">
      Toggle
    </div>
    <!--<transition>-->
      <!--<p class="pp" v-if="show">hello</p>-->
    <!--</transition>-->
    <transition name="hh">
      <div v-show="show">
        <p class="pp"></p>
      </div>
    </transition>
    <Ceshi></Ceshi>
  </div>
</template>

<script>
  import Ceshi from './Ceshi'
  export default {
    name: 'about',
    data(){
      return {
        show: true
      }
    },
    components: {
      Ceshi
    },
    methods: {
      click2(){
        // console.log(this.$route)
        this.$router.push('/active/' + '芜湖')
      },
      click(){
        this.show = !this.show
      }
    },
    activated(){
      console.log(555)
    },
    deactivated(){
      console.log(66)
    },
    errorCaptured(){
      console.log('补货到了错误')
      return false
    }
  }
</script>
<style lang="scss" scoped>
  .con {
    text-align: center;

  }
  .pp {
    width: 300px;
    height: 300px;
    background: red;
    display: inline-block;
  }


  @keyframes fadeIn {
    0%{opacity: 0;}
    100%{opacity: 1;}
  }
  @keyframes fadeOut {
    0%{opacity: 1;}
    100%{opacity: 0;}
  }
  .hh-enter-active {
    animation: fadeIn 3s;
  }

  .hh-leave-active {
    animation: fadeOut 3s;
  }
</style>
