<template>
  <div>
    这里是测试号
    <div>{{show}}</div>
    <div>{{hellow}}</div>
    <div>{{hh}}</div>
    <div>{{did}}</div>
  </div>
</template>

<script>
  const mix = {
    data(){
      return {
        show: true,
        hellow: 'hello world'
      }
    }
  }

export default {
  name: 'Ceshi',
  mixins: [mix],
  created(){
    console.lag('出错了')
},
  beforeRouteEnter(to, from, next){
    if (localStorage.getItem('login') === 'success'){
      if (to.path === '/ceshi'){
        next()
      } else {
        next('/login')
      }
    }else {
      next('/login')
    }
  }
}
</script>

<style scoped lang="scss">

</style>
