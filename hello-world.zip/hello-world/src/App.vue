<template>
  <div id="app">
    <div id="nav">
      <router-link tag="span" to="/">Home</router-link> |
      <router-link tag="span" to="/about">About</router-link>|
      <router-link tag="span" to="/haha">Haha</router-link>|
      <router-link tag="span" to="/hehe">Hehe</router-link>|
      <router-link tag="span" to="/login">login</router-link>|
    </div>
    <!--<transition name="lp" mode="out-in">-->
      <keep-alive>
        <router-view/>
      </keep-alive>
    <!--</transition>-->
    <router-view name="Hehe"></router-view>
  </div>
</template>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  span {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}

@keyframes fadeInApp {
  0%{opacity: 0}
  100%{opacity: 1}
}
@keyframes fadeOutApp {
  0%{opacity: 1}
  100%{opacity: 0}
}
  .lp-enter-active {
    animation: fadeInApp 2s;
  }
  .lp-leave-active {
    animation: fadeOutApp 2s;
  }

</style>
