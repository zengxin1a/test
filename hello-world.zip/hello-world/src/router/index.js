import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    alias: '/pp',
    component: Home
  },
  {
    path: '/haha',
    name: 'Haha',
    components: {
      default: () => import('../views/Haha'),
      Hehe: () => import('../views/Hehe')
    }
  },
  {
    path: '/hehe',
    name: 'hehe',
    component: () => import('../views/Hehe'),
    beforeEnter(to, from, next){
      if (to.path === '/hehe'){
        if (localStorage.getItem('login')){
          next()
        } else {
          next('/login')
        }
      }
    }
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/About.vue'),
    children: [
      {
        path: 'child',  // 注意添加子路由不要加 / 符号
        name: 'Child',
        component: () => import('../views/Child'),
        children: []
      }
    ]
  },
  {
    path: '/active/:id',  // 动态路由这里是id 对应页面取值params.id  也要用id
    name: 'active',
    component: () => import('../views/ActiveRouter'),
    props: true
  },
  {
    path: '/ceshi',
    name: 'Ceshi',
    component: () => import('../views/Ceshi')
  },
  {
    path: '/swiper',
    component: () => import('../components/Swiper')
  },
  {
    path: '/login',
    component: () => import('../views/Login')
  },
  {
    path: '*',
    name: 'NotFound',
    component: () => import('../views/NotFound')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
