<template>
  <div>
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide" v-for="(item, index) in list" :key="index">
          <img :src=item.picUrl alt="">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swiper from 'swiper'
import 'swiper/css/swiper.min.css'
import axios from '../utils/axios'
export default {
  name: 'Swiper',
  data(){
    return {
      list: []
    }
  },
  methods: {
    initSwiper(){
      let mySwiper = new Swiper ('.swiper-container', {
        // direction: 'vertical', // 垂直切换选项
        loop: true, // 循环模式选项

        // 如果需要分页器
        pagination: {
          el: '.swiper-pagination',
        }
      })
    },
    pp(params){
      return axios({
        url: '/item/cateList.json',
        method: 'GET',
        params
      })
    }
  },
  mounted(){
    this.pp({}).then(res => {
      this.list = res.data.currentCategory.bannerList
    })
  },
  watch: {
    list(){
      this.$nextTick(() => {
        this.initSwiper()
      })
    }
  }
}
</script>

<style scoped lang="scss">

</style>
